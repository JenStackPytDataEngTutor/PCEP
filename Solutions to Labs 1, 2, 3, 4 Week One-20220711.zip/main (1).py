﻿class MobilePhone:

    def __init__(self, number):
        self.number = number

    def turn_on(self):
        return 'mobile phone {} is turned on'.format(self.number)

    def turn_off(self):
        return 'mobile phone is turned off'

    def call(self, number):
        return 'calling {}'.format(number)

mobile1 = MobilePhone('01632-960004')
mobile2 = MobilePhone('01632-960012')

print(mobile1.turn_on())
print(mobile2.turn_on())

print(mobile1.call('555-34343'))
print(mobile1.turn_off())
print(mobile2.turn_off())
